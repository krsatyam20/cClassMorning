/* fstream :header file

	ifstream:Used to read information from files.

    ofstream:Used to create files and write information to the files.

*/

#include <iostream>
#include<fstream>
#include<string>
using namespace std;

int main()
{
   // file Write

  ofstream  anilFile("anil.txt");

  if(anilFile.is_open()){

for(int i=1; i<=10;i++) {
    anilFile<<"2" <<"* " <<i  <<"=" <<i*2<<endl;
}
  }

// file read
 string letter;
ifstream anilfileread("anil.txt");
if(anilfileread.is_open()){

while(getline(anilfileread,letter)){

    cout<<letter<<endl;

}
anilfileread.close();

}

    //cout << "Hello world!" << endl;
    return 0;
}
